/*
 * TaskUnifier
 * Copyright (c) 2013, Benjamin Leclerc
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 * 
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 * 
 *   - Neither the name of TaskUnifier or the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
 * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.leclercb.taskunifier.gui.actions;

import com.leclercb.taskunifier.gui.actions.publish.ActionPublish;
import com.leclercb.taskunifier.gui.actions.synchronize.ActionSynchronize;
import com.leclercb.taskunifier.gui.actions.synchronize.ActionSynchronizeAndPublish;
import com.leclercb.taskunifier.gui.constants.Constants;
import com.leclercb.taskunifier.gui.translations.Translations;
import com.leclercb.taskunifier.gui.utils.ImageUtils;

import javax.swing.*;

public enum ActionList {

    SEPARATOR(Translations.getString("general.separator"), "separator.png", true),
    ABOUT(Translations.getString("action.about"), "information.png", true),
    ADD_MODEL(Translations.getString("action.add_model"), "folder.png", false),
    ADD_NOTE(Translations.getString("action.add_note"), "note.png", true),
    ADD_NOTE_SEARCHER(Translations.getString("action.add_note_searcher"), "add.png", true),
    ADD_QUICK_TASK(Translations.getString("action.add_task"), "task.png", false),
    ADD_SUBTASK(Translations.getString("action.add_subtask"), "subtask.png", true),
    ADD_SUBTASK_AT_SAME_LEVEL(Translations.getString("action.add_subtask_at_same_level"), "subtask.png", true),
    ADD_TAB(Translations.getString("action.add_tab"), "tab_add.png", true),
    ADD_TASK(Translations.getString("action.add_task"), "task.png", true),
    ADD_TASK_SEARCHER(Translations.getString("action.add_task_searcher"), "add.png", true),
    ADD_TASK_SEARCHER_SELECTED_TASKS(Translations.getString("action.add_task_searcher_selected_tasks"), "add.png", true),
    ADD_TEMPLATE_TASK(Translations.getString("action.add_template_task"), "template.png", false),
    ADD_TEMPLATE_TASK_MENU(Translations.getString("action.add_template_task"), "template.png", true),
    BATCH_ADD_TASKS(Translations.getString("action.batch_add_tasks"), "batch.png", true),
    CHANGE_DATE_FOLDER_LOCATION(Translations.getString("action.change_data_folder_location"), "folder.png", false),
    CHANGE_VIEW(Translations.getString("action.change_view"), "change_view_tasks.png", true),
    CHECK_PLUGIN_VERSION(Translations.getString("action.check_plugin_version"), "download.png", true),
    CHECK_VERSION(Translations.getString("action.check_version"), "download.png", true),
    CLOSE_TAB(Translations.getString("action.close_tab"), "tab_remove.png", true),
    CLOSE_WINDOW(Translations.getString("action.close_window"), "window_remove.png", true),
    COLLAPSE_ALL(Translations.getString("action.collapse_all"), "collapse.png", true),
    COMPLETE_TASKS(Translations.getString("action.complete_tasks"), "check.png", true),
    CONFIGURATION(Translations.getString("action.configuration"), "settings.png", true),
    COPY(Translations.getString("action.copy"), "copy.png", false),
    CREATE_ACCOUNT(Translations.getString("action.create_account"), "user.png", false),
    CREATE_NEW_BACKUP(Translations.getString("action.create_new_backup"), "save.png", true),
    CREATE_NOTE_FROM_CLIPBOARD(Translations.getString("action.create_note_from_clipboard"), "information.png", true),
    CREATE_NOTE_FROM_TASK(Translations.getString("action.create_note_from_task"), "note.png", true),
    CREATE_TASK_FROM_CLIPBOARD(Translations.getString("action.create_task_from_clipboard"), "information.png", true),
    CREATE_TASK_TEMPLATE_FROM_TASK(Translations.getString("action.create_task_template_from_task"), "template.png", true),
    CUT(Translations.getString("action.cut"), "cut.png", false),
    DELETE(Translations.getString("action.delete"), "remove.png", true),
    DELETE_NOTE_SEARCHER(Translations.getString("action.delete_note_searcher"), "remove.png", true),
    DELETE_TASK_SEARCHER(Translations.getString("action.delete_task_searcher"), "remove.png", true),
    DONATE(Translations.getString("action.donate"), "dollar.png", true),
    DUPLICATE_NOTE_SEARCHER(Translations.getString("action.duplicate_note_searcher"), "duplicate.png", true),
    DUPLICATE_NOTES(Translations.getString("action.duplicate_notes"), "duplicate.png", true),
    DUPLICATE_TASK_SEARCHER(Translations.getString("action.duplicate_task_searcher"), "duplicate.png", true),
    DUPLICATE_TASKS(Translations.getString("action.duplicate_tasks"), "duplicate.png", true),
    EDIT_TASKS(Translations.getString("action.edit_tasks"), "edit.png", true),
    EDIT_NOTE_SEARCHER(Translations.getString("action.edit_note_searcher"), "edit.png", true),
    EDIT_TASK_SEARCHER(Translations.getString("action.edit_task_searcher"), "edit.png", true),
    EXPAND_ALL(Translations.getString("action.expand_all"), "expand.png", true),
    EXPORT_MODELS(Translations.getString("action.export_models"), "upload.png", true),
    EXPORT_NOTE_SEARCHERS(Translations.getString("action.export_note_searchers"), "upload.png", true),
    EXPORT_SETTINGS(Translations.getString("action.export_settings"), "upload.png", true),
    EXPORT_TASK_RULES(Translations.getString("action.export_task_rules"), "upload.png", true),
    EXPORT_TASK_SEARCHERS(Translations.getString("action.export_task_searchers"), "upload.png", true),
    EXPORT_TASK_TEMPLATES(Translations.getString("action.export_task_templates"), "upload.png", true),
    EXPORT_VCARD(Translations.getString("action.export_vcard"), "upload.png", true),
    GET_LOGS(Translations.getString("action.get_logs"), "download.png", true),
    GET_SERIAL(Translations.getString("action.get_serial"), "key.png", false),
    HELP(Translations.getString("action.help"), "help.png", true),
    IMPORT_COM_FILE(Translations.getString("action.import_com_file"), "download.png", true),
    IMPORT_MODELS(Translations.getString("action.import_models"), "download.png", true),
    IMPORT_NOTE_SEARCHERS(Translations.getString("action.import_note_searchers"), "download.png", true),
    IMPORT_SETTINGS(Translations.getString("action.import_settings"), "download.png", true),
    IMPORT_TASK_RULES(Translations.getString("action.import_task_rules"), "download.png", true),
    IMPORT_TASK_SEARCHERS(Translations.getString("action.import_task_searchers"), "download.png", true),
    IMPORT_TASK_TEMPLATES(Translations.getString("action.import_task_templates"), "download.png", true),
    IMPORT_VCARD(Translations.getString("action.import_vcard"), "download.png", true),
    LOG_BUG(Translations.getString("action.log_bug"), null, false),
    LOG_FEATURE_REQUEST(Translations.getString("action.log_feature_request"), null, false),
    LOG_SUPPORT_REQUEST(Translations.getString("action.log_support_request"), null, false),
    MAIL_TO(Translations.getString("action.mail_to"), "mail.png", true),
    MANAGE_BACKUPS(Translations.getString("action.manage_backups"), "save.png", true),
    //MANAGE_LICENSE(Translations.getString("action.manage_license"), "key.png", true),
    MANAGE_MODELS(Translations.getString("action.manage_models"), "folder.png", true),
    MANAGE_PUBLISHER_PLUGINS(Translations.getString("action.manage_publisher_plugins"), "download.png", true),
    MANAGE_SYNCHRONIZER_PLUGINS(Translations.getString("action.manage_synchronizer_plugins"), "download.png", true),
    MANAGE_TASK_CUSTOM_COLUMNS(Translations.getString("action.manage_task_custom_columns"), "column.png", true),
    MANAGE_TASK_RULES(Translations.getString("action.manage_task_rules"), "rule.png", true),
    MANAGE_TASK_TEMPLATES(Translations.getString("action.manage_task_templates"), "template.png", true),
    MANAGE_USERS(Translations.getString("action.manage_users"), "user.png", true),
    NEW_WINDOW(Translations.getString("action.new_window"), "window_add.png", true),
    OPEN_FORUM(Translations.getString("action.open_forum"), null, false),
    PASTE(Translations.getString("action.paste"), "paste.png", false),
    PUBLISH(Translations.getString("action.publish"), "publish.png", true),
    PLUGIN_CONFIGURATION(Translations.getString("action.plugin_configuration"), "settings.png", true),
    POSTPONE_TASK_BEANS(Translations.getString("action.postpone_tasks"), "calendar.png", false),
    POSTPONE_TASKS(Translations.getString("action.postpone_tasks"), "calendar.png", false),
    POSTPONE_TASKS_MENU(Translations.getString("action.postpone_tasks"), "calendar.png", true),
    PRINT(Translations.getString("action.print"), "print.png", true),
    PRINT_SELECTED_MODELS(Translations.getString("action.print_selection"), "print.png", true),
    QUIT(Translations.getString("action.quit"), "exit.png", true),
    REDO(Translations.getString("action.redo"), "redo.png", true),
    REFRESH(Translations.getString("action.refresh"), "synchronize.png", false),
    REMOVE_TAB(Translations.getString("action.remove_tab"), "tab_remove.png", true),
    RENAME_TAB(Translations.getString("action.rename_tab"), "tab_add.png", true),
    RESET_GENERAL_SEARCHERS(Translations.getString("action.reset_general_searchers"), "undo.png", false),
    REVIEW(Translations.getString("action.review"), "information.png", true),
    SAVE(Translations.getString("action.save"), "save.png", false),
    SCHEDULED_SYNC(Translations.getString("action.scheduled_sync"), "synchronize_play.png", true),
    SEARCH(Translations.getString("action.search"), "search.png", true),
    SELECT_PARENT_TASKS(Translations.getString("action.select_parent_tasks"), "task.png", true),
    SHOW_TIPS(Translations.getString("action.show_tips"), "information.png", true),
    SWITCH_TO_USER(Translations.getString("action.switch_user"), "user.png", false),
    SWITCH_TO_USER_MENU(Translations.getString("action.switch_user_menu"), "user.png", true),
    SYNCHRONIZE(Translations.getString("action.synchronize"), "synchronize.png", true),
    SYNCHRONIZE_AND_PUBLISH(Translations.getString("action.synchronize_and_publish"), "synchronize_publish.png", true),
    TASK_REMINDERS(Translations.getString("action.task_reminders"), "clock.png", true),
    UNDO(Translations.getString("action.undo"), "undo.png", true);

    private String title;
    private Icon icon;
    private boolean fitToolBar;

    private ActionList(String title, String icon, boolean fitToolBar) {
        this.title = title;

        if (icon == null)
            this.icon = null;
        else
            this.icon = ImageUtils.getResourceImage(icon, 16, 16);

        this.fitToolBar = fitToolBar;
    }

    public String getTitle() {
        return this.title;
    }

    public Icon getIcon() {
        return this.icon;
    }

    public boolean isFitToolBar() {
        return this.fitToolBar;
    }

    public Action newInstance() {
        return this.newInstance(32, 32);
    }

    public Action newInstance(int width, int height) {
        switch (this) {
            case SEPARATOR:
                return null;
            case ABOUT:
                return new ActionAbout(width, height);
            case ADD_MODEL:
                return null;
            case ADD_NOTE:
                return new ActionAddNote(width, height);
            case ADD_NOTE_SEARCHER:
                return new ActionAddNoteSearcher(width, height);
            case ADD_QUICK_TASK:
                return new ActionAddQuickTask(width, height);
            case ADD_SUBTASK:
                return new ActionAddSubTask(width, height);
            case ADD_SUBTASK_AT_SAME_LEVEL:
                return new ActionAddSubTaskAtSameLevel(width, height);
            case ADD_TAB:
                return new ActionAddTab(width, height);
            case ADD_TASK:
                return new ActionAddTask(width, height);
            case ADD_TASK_SEARCHER:
                return new ActionAddTaskSearcher(width, height);
            case ADD_TASK_SEARCHER_SELECTED_TASKS:
                return new ActionAddTaskSearcherSelectedTasks(width, height);
            case ADD_TEMPLATE_TASK:
                return null;
            case ADD_TEMPLATE_TASK_MENU:
                return new ActionAddTemplateTaskMenu(
                        width,
                        height,
                        ActionAddTemplateTask.ADD_TASK_LISTENER);
            case BATCH_ADD_TASKS:
                return new ActionBatchAddTasks(width, height);
            case CHANGE_DATE_FOLDER_LOCATION:
                return new ActionChangeDataFolderLocation(width, height);
            case CHANGE_VIEW:
                return new ActionChangeView(width, height);
            case CHECK_PLUGIN_VERSION:
                return new ActionCheckPluginVersion(width, height, false);
            case CHECK_VERSION:
                return new ActionCheckVersion(width, height, false);
            case CLOSE_TAB:
                return new ActionCloseTab(width, height);
            case CLOSE_WINDOW:
                return new ActionCloseWindow(width, height);
            case COLLAPSE_ALL:
                return new ActionCollapseAll(width, height);
            case COMPLETE_TASKS:
                return new ActionCompleteTasks(width, height);
            case CONFIGURATION:
                return new ActionConfiguration(width, height);
            case COPY:
                return new ActionCopy(width, height);
            case CREATE_ACCOUNT:
                return null;
            case CREATE_NEW_BACKUP:
                return new ActionCreateNewBackup(width, height);
            case CREATE_NOTE_FROM_CLIPBOARD:
                return new ActionCreateNoteFromClipboard(width, height);
            case CREATE_NOTE_FROM_TASK:
                return new ActionCreateNoteFromTask(width, height);
            case CREATE_TASK_FROM_CLIPBOARD:
                return new ActionCreateTaskFromClipboard(width, height);
            case CREATE_TASK_TEMPLATE_FROM_TASK:
                return new ActionCreateTaskTemplateFromTask(width, height);
            case CUT:
                return new ActionCut(width, height);
            case DELETE:
                return new ActionDelete(width, height);
            case DELETE_NOTE_SEARCHER:
                return new ActionDeleteNoteSearcher(width, height);
            case DELETE_TASK_SEARCHER:
                return new ActionDeleteTaskSearcher(width, height);
            case DONATE:
                return new ActionDonate(width, height);
            case DUPLICATE_NOTE_SEARCHER:
                return new ActionDuplicateNoteSearcher(width, height);
            case DUPLICATE_NOTES:
                return new ActionDuplicateNotes(width, height);
            case DUPLICATE_TASK_SEARCHER:
                return new ActionDuplicateTaskSearcher(width, height);
            case DUPLICATE_TASKS:
                return new ActionDuplicateTasks(width, height);
            case EDIT_NOTE_SEARCHER:
                return new ActionEditNoteSearcher(width, height);
            case EDIT_TASK_SEARCHER:
                return new ActionEditTaskSearcher(width, height);
            case EDIT_TASKS:
                return new ActionEditTasks(width, height);
            case EXPAND_ALL:
                return new ActionExpandAll(width, height);
            case EXPORT_MODELS:
                return new ActionExportModels(width, height);
            case EXPORT_NOTE_SEARCHERS:
                return new ActionExportNoteSearchers(width, height);
            case EXPORT_SETTINGS:
                return new ActionExportSettings(width, height);
            case EXPORT_TASK_RULES:
                return new ActionExportTaskRules(width, height);
            case EXPORT_TASK_SEARCHERS:
                return new ActionExportTaskSearchers(width, height);
            case EXPORT_TASK_TEMPLATES:
                return new ActionExportTaskTemplates(width, height);
            case EXPORT_VCARD:
                return new ActionExportVCard(width, height);
            case GET_SERIAL:
                return null;
            case HELP:
                return new ActionHelp(width, height);
            case IMPORT_COM_FILE:
                return new ActionImportComFile(width, height);
            case IMPORT_MODELS:
                return new ActionImportModels(width, height);
            case IMPORT_NOTE_SEARCHERS:
                return new ActionImportNoteSearchers(width, height);
            case IMPORT_SETTINGS:
                return new ActionImportSettings(width, height);
            case IMPORT_TASK_RULES:
                return new ActionImportTaskRules(width, height);
            case IMPORT_TASK_SEARCHERS:
                return new ActionImportTaskSearchers(width, height);
            case IMPORT_TASK_TEMPLATES:
                return new ActionImportTaskTemplates(width, height);
            case IMPORT_VCARD:
                return new ActionImportVCard(width, height);
            case LOG_BUG:
                return new ActionLogBug();
            case LOG_FEATURE_REQUEST:
                return new ActionLogFeatureRequest();
            case MAIL_TO:
                return new ActionMailTo(width, height);
            case MANAGE_BACKUPS:
                return new ActionManageBackups(width, height);
            //case MANAGE_LICENSE:
                //return new ActionManageLicense(width, height);
            case MANAGE_MODELS:
                return new ActionManageModels(width, height);
            case MANAGE_PUBLISHER_PLUGINS:
                return new ActionManagePublisherPlugins(width, height);
            case MANAGE_SYNCHRONIZER_PLUGINS:
                return new ActionManageSynchronizerPlugins(width, height);
            case MANAGE_TASK_CUSTOM_COLUMNS:
                return new ActionManageTaskCustomColumns(width, height);
            case MANAGE_TASK_RULES:
                return new ActionManageTaskRules(width, height);
            case MANAGE_TASK_TEMPLATES:
                return new ActionManageTaskTemplates(width, height);
            case MANAGE_USERS:
                return new ActionManageUsers(width, height);
            case NEW_WINDOW:
                return new ActionNewWindow(width, height);
            case PASTE:
                return new ActionPaste(width, height);
            case PUBLISH:
                return new ActionPublish(width, height, false);
            case PLUGIN_CONFIGURATION:
                return new ActionPluginConfiguration(width, height);
            case POSTPONE_TASK_BEANS:
                return null;
            case POSTPONE_TASKS:
                return null;
            case POSTPONE_TASKS_MENU:
                return new ActionPostponeTasksMenu(width, height, null);
            case PRINT:
                return new ActionPrint(width, height);
            case PRINT_SELECTED_MODELS:
                return new ActionPrintSelectedModels(width, height);
            case QUIT:
                return new ActionQuit(width, height);
            case REDO:
                return Constants.UNDO_SUPPORT.getRedoAction();
            case REFRESH:
                return new ActionRefresh(width, height);
            case REMOVE_TAB:
                return new ActionRemoveTab(width, height);
            case RENAME_TAB:
                return new ActionRenameTab(width, height);
            case RESET_GENERAL_SEARCHERS:
                return new ActionResetGeneralSearchers(width, height);
            case REVIEW:
                return new ActionReview(width, height);
            case SAVE:
                return new ActionSave(width, height);
            case SCHEDULED_SYNC:
                return new ActionScheduledSync(width, height);
            case SEARCH:
                return new ActionSearch(width, height);
            case SELECT_PARENT_TASKS:
                return new ActionSelectParentTasks(width, height);
            case SHOW_TIPS:
                return new ActionShowTips(width, height);
            case SWITCH_TO_USER:
                return null;
            case SWITCH_TO_USER_MENU:
                return new ActionSwitchToUserMenu(width, height);
            case SYNCHRONIZE:
                return new ActionSynchronize(width, height, false);
            case SYNCHRONIZE_AND_PUBLISH:
                return new ActionSynchronizeAndPublish(width, height, false);
            case TASK_REMINDERS:
                return new ActionTaskReminders(width, height);
            case UNDO:
                return Constants.UNDO_SUPPORT.getUndoAction();
            default:
                return null;
        }
    }

}
